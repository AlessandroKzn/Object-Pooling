﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBehaviour : MonoBehaviour {

	Transform target;
	public float speed;

	public int lifePoints; 
	public GameObject shootPrefab; 
	public Transform spawnPoint; 
	float timer;
	public float fireRate;
	public int points;
	GameObject GC;
	// Use this for initialization
	void Start () {

		target = GameObject.FindGameObjectWithTag ("Player").transform;
		GC = GameObject.FindGameObjectWithTag ("GameController");
		timer = 0;

	}
	
	// Update is called once per frame
	void FixedUpdate () {
		
		timer += Time.deltaTime; 

		MoveEnemy ();
		Fire ();
	}

	void MoveEnemy(){

		transform.position = Vector2.MoveTowards (transform.position,
			target.position, speed * Time.deltaTime);

	}

	void Fire(){

		if (timer > fireRate) {

			Instantiate (shootPrefab, spawnPoint.position, spawnPoint.rotation);
			timer = 0f;

		}
	}

	void ApplyDamage(int dmg){

		lifePoints -= dmg;

		if (lifePoints <= 0) {
			GC.SendMessage ("AddPoints", points, SendMessageOptions.DontRequireReceiver);
			Destroy (gameObject);
		}
	}

}