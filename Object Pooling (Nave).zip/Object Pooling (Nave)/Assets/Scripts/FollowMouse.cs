﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowMouse : MonoBehaviour {

	Vector2 direction; // direção qe o player irá 'olhar'
	Vector3 mousePos; // posição do mouse
	public float lerpTime; // tempo de 'transição' 

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		FaceMouse ();
	}

	void FaceMouse(){

		mousePos = Input.mousePosition; // captura a posição do mouse;
		mousePos = Camera.main.ScreenToWorldPoint(mousePos);

		direction = new Vector2 (mousePos.x - transform.position.x, 
								 mousePos.y - transform.position.y);

		// transform.up = direction; // rotacionar o player em velocidade normal
		transform.up = Vector3.Lerp(transform.up, direction, lerpTime);

	}
}
