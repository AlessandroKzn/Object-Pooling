﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour {

	Transform target;
	Vector2 direction;

	// Use this for initialization
	void Start () {

		target = GameObject.FindGameObjectWithTag ("Player").transform;

	}
	
	// Update is called once per frame
	void Update () {


		direction = new Vector2(target.position.x - transform.position.x, 
								target.position.y - transform.position.y);
			//transform.up = direction;

		transform.up = Vector3.Lerp (transform.up, -direction, 0.05f);
	}
}
