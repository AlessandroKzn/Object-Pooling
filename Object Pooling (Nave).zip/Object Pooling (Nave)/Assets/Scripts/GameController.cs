﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

	bool gameOver;
	AudioSource gcas;
	public AudioClip fim;
	int points;
	public Text scoreText;
	public Text gameOverText;
	public Text lifeText;
	public int maxEnemies;
	int enemiesSpawned;
	bool fimc = false;

	// Use this for initialization
	void Start () {
		fimc = false;
		gcas = GetComponent<AudioSource> ();
		gameOver = false;
		Time.timeScale = 1;

		points = 0;
		gameOverText.gameObject.SetActive (false);
		enemiesSpawned = 0;

	}
	
	// Update is called once per frame
	void Update () {

		Reset ();

		SetScoreText ();

		DeactiveSpawnPoints ();

		VerifyEnemiesInGame ();

	}

	void GameOver(){

		gameOver = true;
		Time.timeScale = 0;
		SetGameOverText ();
		gameOverText.gameObject.SetActive (true);
		if (!gcas.isPlaying && fimc == false)
		{
			gcas.PlayOneShot (fim, 5f);
			fimc = !false;
		}

	}

	void Reset(){
		if (gameOver) {

			if (Input.GetKeyDown (KeyCode.R)) {
				SceneManager.LoadScene ("Main");
			}
		}
	}


	void AddPoints(int p){
		points += p;
	}

	void SetScoreText(){
		scoreText.text = "Score: " + points + " pts";
	}


	void SetLifeText(int lifePoints){
		lifeText.text = "Energy: " + lifePoints + "%";
	}

	void SetGameOverText(){
		gameOverText.text = "Game Over\nFinal Score: " + points + "pts";
	}

	void CountEnemies(){
		enemiesSpawned++;
	}

	void DeactiveSpawnPoints(){

		if (enemiesSpawned == maxEnemies) {

			GameObject[] enemiesSpawnPoints = GameObject.FindGameObjectsWithTag ("EnemySpawn");

			for (int i = 0; i < enemiesSpawnPoints.Length; i++) {
				enemiesSpawnPoints [i].gameObject.SetActive (false);
			}

		}

	}

	void VerifyEnemiesInGame(){
		GameObject[] enemiesInGame = GameObject.FindGameObjectsWithTag ("Enemy");

		if (enemiesInGame.Length == 0) {
			GameOver ();
		}
			
	}


}
