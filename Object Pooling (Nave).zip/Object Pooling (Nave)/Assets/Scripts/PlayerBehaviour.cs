﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBehaviour : MonoBehaviour {

	public float speed;
	float directionX;
	float directionY;

	public GameObject shootPrefab;
	public Transform spawnPoint;

	public float fireRate;
	float timer;

	public int lifePoints;

	AudioSource pas;
	public AudioClip song;

	GameObject GC; // game controller

	Animator playerAnim;



	// Use this for initialization
	void Start () {
		pas = GetComponent<AudioSource> ();
		timer = 0f;
		GC = GameObject.FindGameObjectWithTag ("GameController");
		playerAnim = GetComponentInChildren<Animator> ();
		GC.SendMessage ("SetLifeText", lifePoints);
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		timer += Time.deltaTime;

		MovePlayer ();

		Fire ();


	}

	void MovePlayer(){

		directionX = Input.GetAxisRaw ("Horizontal");
		directionY = Input.GetAxisRaw ("Vertical");

		if (directionX != 0 || directionY != 0) {
			playerAnim.SetBool ("IsMoving", true);

		} else if (directionX == 0 && directionY == 0) {
			playerAnim.SetBool ("IsMoving", false);
		}


		transform.Translate(new Vector2(directionX, directionY) * speed * Time.deltaTime);
	}

	void Fire(){

		if (Input.GetKey (KeyCode.Mouse0) && timer > fireRate) {

			Instantiate (shootPrefab, spawnPoint.transform.position, 
				spawnPoint.rotation);
			pas.PlayOneShot (song, 0.9f);

			timer = 0f;
		}
	}

	void ApplyDamage(int dmg){

		lifePoints -= dmg;
		GC.SendMessage ("SetLifeText", lifePoints);

		if (lifePoints <= 0) {
			GC.SendMessage ("GameOver");
			gameObject.SetActive (false);
		}

	}
		
}
