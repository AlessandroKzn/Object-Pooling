﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnEnemy : MonoBehaviour {

	GameObject GC;
	public GameObject enemy;
	public float timeToSpwan;
	float timer;

	// Use this for initialization
	void Start () {
		GC = GameObject.FindGameObjectWithTag ("GameController");
		timer = 0;
	}
	
	// Update is called once per frame
	void Update () {

		timer += Time.deltaTime;

		if (timer > timeToSpwan) {

			Instantiate (enemy, transform.position, enemy.transform.rotation);
			timer = 0f;
			GC.SendMessage ("CountEnemies", SendMessageOptions.DontRequireReceiver);
		}

	}
}
